import os
import google.generativeai as genai

# API-KEYの設定
genai.configure(api_key='AIzaSyDIOSHb1tAUisHOTexjoDXp8_jRc_eFKys')

# モデルの生成
gemini_pro = genai.GenerativeModel("gemini-pro")



print('\'end\' と打てばチャットが終了します。')
while True:
    # プロンプトの設定
    prompt = input()
    if prompt == "end":
        break
    
    if prompt != "":
        # テキスト生成
        response = gemini_pro.generate_content(prompt)

        # 生成結果の表示
        print(response.text)

